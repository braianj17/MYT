<?php
error_reporting(E_ERROR | E_WARNING | E_PARSE);
define("KEY","develoteca");
define("COD","AES-128-ECB");
define("SERVIDOR","localhost");
define("USUARIO","root");
define("PASSWORD","");
define("BD","tienda");
define("DESCARGASPERMITIDAS","1");




/*define("SERVIDOR","localhost");
define("USUARIO","arksoluc_braian");
define("PASSWORD","braian.123b");
define("BD","arksoluc_tienda");
define("DESCARGASPERMITIDAS","1");*/


//SANDBOX
define("LINKAPI","https://api.sandbox.paypal.com");
define("CLIENTID","AYnfNUNXFfqeWqlt3j3n0OAQs3w3xiwbHF9QWX7gopLG0xURSskjoVMu-fu-7TAI5CtN7djVSY1_ONsZ");
define("SECRET","EMzGjDKaaBOIIEk6NU_9yHThydB9yGzOKQElRjxTbFdCM7HByU6VWcNBk9srOk6nrzT1PZ_e6mUw8r8O");


//LIVE
/*define("LINKAPI","https://api.paypal.com");
define("CLIENTID","AWfB5CQzwjNuzzQBgV9kCd9HaSfx6C0vkBRUMxcQFsn-t0QDRKrt4e-ZSpHD_I-4t36BteCEoyefTCpo");
define("SECRET","EOTe7cRCNHF5Yw78fGvrJzTMZBiqftfgKANWIxYkoexACCMdTgoAO8Z6VsbhEqEHuxXBtN0e1l1jOTr0");
*/
?>