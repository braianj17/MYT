<link rel="stylesheet" type="text/css" href="CSSnew/serv.css"> 
<div class="feat bg-gray pt-5 pb-5">
    <div class="container">
      <div class="row">
        <div class="section-head col-sm-12">
          <h4><span>Nuestros </span> Servicios</h4>
          <p>Satisfacemos las necesidades de nuestros clientes ofreciendo soluciones <br> dentro de un marco tecnológico y de vanguardia.</p>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="item" > <span class="icon feature_box_col_one"><i class="fa fa-briefcase"></i></span>
            <h6>Servicio Predictivo</h6>
            <p>Se realizan pruebas dependiendo el equipo para detectar posibles fallas.<br><br></p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="item2"> <span class="icon feature_box_col_two"><i class="fa fa-exclamation-triangle"></i></span>
            <h6>Servicio Preventivo</h6>
            <p>Se realizan trabajos periódicamente destinados a la conservación y duración de los equipos.</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="item3"> <span class="icon feature_box_col_three"><i class="fa fa-wrench"></i></span>
            <h6>Servicio Correctivo</h6>
            <p>Consiste en restaurar la integridad, la seguridad o el funcionamiento del equipo.</p>
          </div>
        </div>

 
      </div>
    </div>
  </div>