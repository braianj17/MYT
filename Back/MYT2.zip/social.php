 <!-- barra de redes sociales  -->
 <link rel="stylesheet" href="CSSnew/estilos.css">
      
	   

<div class="social">
          <ul>
            <li>
              <a href="http://www.facebook.com/myt.medicalsolutions" target="_blank" class="icon-facebook"></a>
            </li>
            <li>
              <a href="https://www.instagram.com/" target="_blank" class="icon-instagram"></a>
            </li>
            <li>
              <a href="tel:+2227883380" target="_blank" class="icon-phone"></a>
            </li>
            <li>
              <a href="mailto:myt.atencionyventas@gmail.com" class="icon-mail4"></a>
            </li>
          </ul>
        </div>