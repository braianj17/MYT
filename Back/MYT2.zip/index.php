<!DOCTYPE html>
    <html lang="en">
    <link rel="stylesheet" type="text/css" href="CSSnew/search.css"> 
    <!-- maus-->
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
    <link rel="stylesheet" href="maus.css">
    <!-- maus-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>
<link rel="stylesheet" href="style.css">

       
        <?php include "head.php" ?>
            <body>
                <?php include "social.php" ?>
                    <!-- ======= Header ======= -->
                    <?php include "header.php" ?>
                        <!-- End Header -->
                        <!-- ======= Hero Section ======= -->
                       
                 
      <!-- partial:index.partial.html -->
<div class="wrapper">
  <input checked type=radio name="slider" id="slide1" />
  <input type=radio name="slider" id="slide2" />
  <input type=radio name="slider" id="slide3" />
  <input type=radio name="slider" id="slide4" />
  <input type=radio name="slider" id="slide5" />

  <div class="slider-wrapper">
    <div class=inner>
      <article>
        <div class="info top-left">
          
          <h3>Malacca</h3></div>
        <img src="assets/img/f15.png" />
      </article>

      <article>
        <div class="info bottom-right">
          <h3>Cameron Highland</h3></div>
        <img src="assets/img/f16.png" />
      </article>

      <article>
        <div class="info bottom-left">
          <h3>New Delhi</h3></div>
        <img src="assets/img/f17.png" />
      </article>

      <article>
        <div class="info top-right">
          <h3>Ladakh</h3></div>
        <img src="assets/img/f18.jpg" />
      </article>

      <article>
        <div class="info bottom-left">
          <h3>Nubra Valley</h3></div>
        <img src="assets/img/f19.jpg" />
      </article>
    </div>
    <!-- .inner -->
  </div>
  <!-- .slider-wrapper -->

  <div class="slider-prev-next-control">
    <label for=slide1></label>
    <label for=slide2></label>
    <label for=slide3></label>
    <label for=slide4></label>
    <label for=slide5></label>
  </div>
  <!-- .slider-prev-next-control -->

  <div class="slider-dot-control">
    <label for=slide1></label>
    <label for=slide2></label>
    <label for=slide3></label>
    <label for=slide4></label>
    <label for=slide5></label>
  </div>
  <!-- .slider-dot-control -->
</div>
               
                            <?php include "maus.php" ?>
                        <!-- End Hero -->
                            <?php include "portaf.php" ?>
                            <?php include "serv.php" ?>
                                <!-- ======= wh ======= -->
                                <?php include "whats.php" ?>
                                <!-- ======= wh ======= -->
                                <!-- ======= Footer ======= -->
                                    <?php include "footer.php" ?>
                                    <!-- End  Footer -->
                                    <div id="preloader">
                                    </div>
                                        <a href="#" class="back-to-top"><i class="bx bx-up-arrow-alt"></i></a>
                                            <!-- Vendor JS Files -->
                                            <?php include "script.php" ?>
                                              <!-- maus-->
                                            <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js'></script>
                                            <script  src="maus.js"></script>
                                            <!-- maus-->
                                            <script  src="./script.js"></script>
      </body>
    </html>