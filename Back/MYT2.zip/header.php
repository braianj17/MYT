<main>
<header id="header" class="fixed-top">
            <div class="container-fluid d-flex justify-content-between align-items-center">
              <h1 class="logo">
                <img src="assets/img/log4.png"> 
                &nbsp;&nbsp;&nbsp;  <a href="index.html" style="color: #32bad4;">
                    MYT
                  </a>
              </h1>
             <!-- <a href="index.html" class="logo">
                <img src="assets/img/log2.png" alt="" class="img-fluid">
              </a>-->
              <nav class="nav-menu d-none d-lg-block">
                <ul>
                  <li class="active"><a href="index.php">Inicio</a></li>
                  <li><a href="about.php">Acerca de</a></li>
                   <!--<li><a href="-resume.html">Resumen</a></li>-->
                  <li><a href="services.html">Servicios</a></li>
                  <li><a href="portfolio.php">Productos</a></li>
                  <li><a href="contact.html">Contacto</a></li>
                </ul>
              </nav><!-- .nav-menu -->
              <div class="header-social-links">
                <a href="http://www.facebook.com/myt.medicalsolutions" class="facebook"><i class="icofont-facebook"></i></a>
                <a href="https://www.instagram.com/" class="instagram"><i class="icofont-instagram"></i></a>
                <a href="mailto:myt.atencionyventas@gmail.com" class="email"><i class="icofont-ui-email"></i></i></a>
                <a href="tel:+2227883380" class="phone"><i class="icofont-phone"></i></i></a>
              </div>
            </div>
          </header>