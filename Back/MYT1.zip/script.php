         

         
         <script src="assets/vendor/jquery/jquery.min.js"></script><!-- animacion de carga --> 
              <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script><!-- flecha para subir al inicio --> 
              <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script><!-- carga elementos --> 
              <script src="assets/vendor/counterup/counterup.min.js"></script><!-- carga elementos --> 
              <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script><!-- carga elementos --> 
              <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script><!-- carga elementos --> 
              <script src="assets/vendor/venobox/venobox.min.js"></script><!-- carga ventana del portafolio --> 
              <script src="assets/vendor/aos/aos.js"></script><!-- carga elementos --> 
              <script src="assets/js/main.js"></script><!-- carga inicio --> 
            
              <!--/ End WhatsChat Layout Section -->
              <!-- WhatsChat style2 js library  (required) -->
              <script src="js/whatschat-style7.js"></script>