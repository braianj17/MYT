
	    
<!-- WhatsChat Layout CSS  (required) -->
<link rel="stylesheet" type="text/css" href="css/animate.min.css"/>
	    <!-- WhatsChat Layout CSS -->
	    
	    <!-- WhatsChat Custom Style-1 CSS  (required) -->
	    <link rel="stylesheet" type="text/css" href="css/style/whatschat-style7.css"/>
	    <!-- WhatsChat Color CSS (This is only for Live Demo) -->
	    <link id="whatschat-color" rel="stylesheet" href="css/colors/color-blue.css">
       


<div class="wc-style7" > <!-- Floating Button-->
              <a class="wc-button">
                <i id="wc-whatsapp" class="fab fa-whatsapp" aria-hidden="true"></i>
                <i id="wc-times" class="far fa-minus-square" aria-hidden="true"></i>
              </a><!-- Chat Panel -->
              <div class="wc-panel "><!-- Panel Header Content -->
                <div class="wc-header"><!-- Profile Picture -->
                  <div class="wc-img-cont">
                    <img class="wc-user-img" src="img/profile_02.jpg"/>
                  </div><!-- Display Name & Last Seen -->
                  <div class="wc-user-info">
                    <strong>Atencion a clientes</strong>
                      <p>Asistencia</p>
                  </div>
                </div><!-- Panel Body Content -->
                <div class="wc-body">
                  <div class="wc-content">
                    <div class="wc-bubble tri-right left-top">
                      <span>Recepcion.</span>
                        <br>
                        <p>Hola, estoy aquí 👋</p>
                        <p>Chatiemos!!!</p>
                    </div>
                  </div>
                </div><!-- Panel Footer Content -->
                <div class="wc-footer"><!-- Start Single Contact List 22 21 86 53 15 -->
                  <a class="wc-list" number="+522221865315" message="Gracias Por Comunicarte, en que puedo ayudarte?">
                    <i class="fa fa-whatsapp" aria-hidden="true"></i>
                      <p>Chat</p>
                  </a>
                </div>
              </div>
            </div>
