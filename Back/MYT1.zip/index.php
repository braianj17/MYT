<!DOCTYPE html>
    <html lang="en">
    <link rel="stylesheet" type="text/css" href="CSSnew/search.css"> 
    <!-- maus-->
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
    <link rel="stylesheet" href="maus.css">
    <!-- maus-->
        <?php include "head.php" ?>
            <body>
                <?php include "social.php" ?>
                    <!-- ======= Header ======= -->
                    <?php include "header.php" ?>
                        <!-- End Header -->
                        <!-- ======= Hero Section ======= -->
                        <section id="hero" class="d-flex align-items-center">
                 
         
  <div class="container d-flex flex-column align-items-center" data-aos="zoom-in" data-aos-delay="100">
                                <h1 style="color: #32bad4;">MYT</h1>
                                    <h2>Medical Technology Puebla</h2>
                                    <div class="search-box">
  <input type="search" placeholder="Busca aquí..." />
  <button type="submit" class="search-btn"><i class="fa fa-search"></i></button>
</div>
                            </div> 

                            
                            <?php include "maus.php" ?>
    
                        </section><!-- End Hero -->
                            <?php include "portaf.php" ?>
                            <?php include "serv.php" ?>
                                <!-- ======= wh ======= -->
                                <?php include "whats.php" ?>
                                <!-- ======= wh ======= -->
                                <!-- ======= Footer ======= -->
                                    <?php include "footer.php" ?>
                                    <!-- End  Footer -->
                                    <div id="preloader">
                                    </div>
                                        <a href="#" class="back-to-top"><i class="bx bx-up-arrow-alt"></i></a>
                                            <!-- Vendor JS Files -->
                                            <?php include "script.php" ?>
                                              <!-- maus-->
                                            <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js'></script>
                                            <script  src="maus.js"></script>
                                            <!-- maus-->
      </body>
    </html>