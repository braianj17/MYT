
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
<link rel="stylesheet" type="text/css" href="CSSnew/foot.css"> 
<footer class="new_footer_area bg_color">
            <div class="new_footer_top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-6">
                            <div class="f_widget company_widget wow fadeInLeft" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInLeft;">
                                <h3 class="f-title f_600 t_color f_size_18">Ponerse en Contacto</h3>
                                <p>No se pierda nuestros nuevos productos y servicios!</p>
                                <form action="#" class="f_subscribe_two mailchimp" method="post" novalidate="true" _lpchecked="1">
                                    <input type="text" name="EMAIL" class="form-control memail" placeholder="Email">
                                    <button class="btn btn_get btn_get_two" type="submit">Subscribir</button>
                                    <p class="mchimp-errmessage" style="display: none;"></p>
                                    <p class="mchimp-sucmessage" style="display: none;"></p>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="f_widget about-widget pl_70 wow fadeInLeft" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInLeft;">
                                <h3 class="f-title f_600 t_color f_size_18">Descarga</h3>
                                <ul class="list-unstyled f_list">
                                    <li><a href="#">Compañia</a></li>
                                    <li><a href="#">Android App</a></li>
                                    <li><a href="#">ios App</a></li>
                                    <li><a href="#">Productos</a></li>
                                    <li><a href="#">Servicios</a></li>
                                    <li><a href="#">Otros</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="f_widget about-widget pl_70 wow fadeInLeft" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInLeft;">
                                <h3 class="f-title f_600 t_color f_size_18">Ayuda</h3>
                                <ul class="list-unstyled f_list">
                                    <li><a href="#">Preguntas mas frecuentes</a></li>
                                    <li><a href="#">Terminos &amp; condiciones</a></li>
                                    <li><a href="#">Reportando</a></li>
                                    <li><a href="#">Documentacion</a></li>
                                    <li><a href="#">Politica de Soporte</a></li>
                                    <li><a href="#">Privacidad</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="f_widget social-widget pl_70 wow fadeInLeft" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInLeft;">
                                <h3 class="f-title f_600 t_color f_size_18">Soluciones</h3>
                                <div class="f_social_icon">
                                    <a href="http://www.facebook.com/myt.medicalsolutions" class="fab fa-facebook"></a>
                                    <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
                                    <a href="mailto:myt.atencionyventas@gmail.com" class="fas fa-envelope"></a>
                                    <a href="tel:+2227883380"  class="fas fa-phone"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer_bg">
                    <div class="footer_bg_one"></div>
                    <div class="footer_bg_two"></div>
                </div>
            </div>
            <div class="footer_bottom">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-sm-7">
                            <p class="mb-0 f_400">© Braian dev.. 2021 Todos los derechos reservados.</p>
                        </div>
                        <div class="col-lg-6 col-sm-5 text-right">
                            <p>Hecho <i class="icon_heart"></i> in <a href="#">ARK</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        </main>