<!DOCTYPE html>
<html lang="en">

<?php include "head.php" ?>
<link rel="stylesheet" type="text/css" href="CSSnew/produ.css"> 
<body>

  <!-- ======= Header ======= -->


  <?php include "header.php" ?>

  <!-- End Header -->

  <main id="main">

    <section>
      <h1>NUESTROS PRODUCTOS </h1>
    <div class="list">
          <div class="product">
            <img alt="shoes1" src="productos/p2.png">
            <div><h3>ACCESORIOS</h3>
             <!-- <p class="price">15<sup>.00</sup></p>-->
              <p class="descr">Lorem ipsum dolor sit amet, consectetur adipiscing elit<b>incididunt ut labore et dolore magna aliqua</b></p>
            <br>
            <a href="#"><p>Ver el catalogo</p></a></div>
          </div>
          <div class="product">
            <img alt="shoes2" src="productos/p1.png">
            <div><h3>CUBREBOCAS</h3>
               <!--<p class="price">15<sup>.00</sup></p>-->
              <p class="descr">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
            <br>
            <a href="#"><p>Ver el catalogo</p></a></div>
          </div>
          <div class="product">
            <img alt="shoes3" src="productos/p3.png">
            <div><h3>MAQUINAS</h3>
               <!--<p class="price">15<sup>.00</sup></p>-->
              <p class="descr">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
            <br>
            <a href="#"><p>Ver el catalogo</p></a></div>
          </div>
           <div class="product">
            <img alt="shoes4"  src="productos/p4.png">
            <div><h3>DERMAX</h3>
               <!--<p class="price">15<sup>.00</sup></p>-->
              <p class="descr">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
            <br>
            <a href="#"><p>Ver el catalogo</p></a></div>
          </div> 
    </div>
    </section>
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include "footer.php" ?>
  <!-- End  Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top"><i class="bx bx-up-arrow-alt"></i></a>

 <!-- Vendor JS Files -->
 <?php include "script.php" ?>
</body>

</html>